import os
import json
import instructor
from openai import OpenAI
from pydantic import BaseModel, Field
from verifier import verify 

# define Schema
class BugFixSolution(BaseModel):
    thought_process: str = Field(description="Step-by-step reasoning.")
    fixed_verilog_code: str = Field(description="The complete fixed SystemVerilog code.")

def run_baseline_evaluation():
    my_api_key = os.environ.get("OPENAI_API_KEY")
    

    client = instructor.patch(OpenAI(api_key=my_api_key))

    # Prompt setup
    prompts = {
        "P1": "You are a verification engineer. There is a bug in the ADD instruction (state s_1) where the ALU control signal is wrong. Please fix it and return the code.",
        "P2": "You are a verification engineer. There is a routing bug in the JSR instruction (state s_4). It jumps to the wrong state. Please fix it and return the code.",
        "P3": "A junior engineer reported that there are bugs in control signal. Please fix this bug.",
        "P4": "Please fix the routing error for the JSR instruction (state s_4).",
        "P5": "Please fix the ADD instruction (wrong ALU opcode) and the JSR instruction (wrong target state). Make sure all other instructions pass the regression tests.",
        
        # added problems for HW4
        "P6": "Fix the arithmetic operator error in the ALU. The bitwise AND instruction is incorrectly implemented using a logical AND (&&).",
        "P7": "Resolve the multiplexer routing error in the CPU datapath. The SR1MUX ternary operator has its true and false branches swapped.",
        "P8": "Fix the bitwise AND operator (&& instead of &) in alu.sv. Ensure immediate-mode arithmetic works.",
        "P9": "Fix the SR1MUX routing error in cpu.sv. Ensure the whole datapath works.",
        "P10": "Fix the SR2MUX routing error in cpu.sv and the NOT operand error in alu.sv. Ensure all tests pass."
    }

    # =file set
    files = {
        "P1": "buggy_control_p1.sv", "P2": "buggy_control_p2.sv", 
        "P3": "buggy_control_p3.sv", "P4": "buggy_control_p4.sv", "P5": "buggy_control_p5.sv",
        "P6": "buggy_alu_p6.sv",
        "P7": "buggy_cpu_p7.sv",
        "P8": "buggy_combined_p8.sv",
        "P9": "buggy_combined_p9.sv",
        "P10": "buggy_combined_p10.sv"
    }

    problems = ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"]
    
    print(f"{'Problem':<10} | {'T1':<5} {'T2':<5} {'T3':<5} {'T4':<5} {'T5':<5} | {'Pass Rate'}")
    print("-" * 50)

    latex_table_rows = []
    full_log = [] # used to save the .json file

    for p in problems:
        # read the corresponding buggy code
        filename = files[p]
        try:
            with open(filename, "r", encoding="utf-8") as f:
                buggy_code = f.read()
        except FileNotFoundError:
            print(f"Warning: File {filename} not found! Skipping {p}...")
            continue

        prompt = f"{prompts[p]}\n\nCode:\n```systemverilog\n{buggy_code}\n```"
        
        results = []
        pass_count = 0

        print(f"Running {p}... ", end="", flush=True)

        for trial in range(1, 6):
            try:
                # use the LLM
                response = client.chat.completions.create(
                    model="gpt-4o",
                    response_model=BugFixSolution,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.0, 
                )

                # use the verifier
                result = verify(p, response)
                
                # .json 
                full_log.append({
                    "problem_id": p,
                    "trial": trial,
                    "pass": result["pass"],
                    "reason": result["reason"]
                })

                if result["pass"]:
                    results.append("P")
                    pass_count += 1
                else:
                    results.append("F")
            
            except Exception as e:
                # if API fail
                results.append("E")
                full_log.append({"problem_id": p, "trial": trial, "pass": False, "reason": f"API/Execution Error: {str(e)}"})

        # print the table
        row_str = " ".join([f"{res:<5}" for res in results])
        print(f"[{row_str}] | {pass_count}/5")
        

        difficulty = 'Easy' if p in ['P1','P2','P6','P7'] else 'Hard'
        latex_row = f"{p} & Family {'A' if p in ['P1','P2','P3','P4','P5'] else 'B'} & {difficulty} & " + " & ".join(results) + f" & {pass_count}/5 \\\\"
        latex_table_rows.append(latex_row)


    print("\n>>> LaTeX Table Rows:")
    for row in latex_table_rows:
        print(row)

    # save the .json file
    with open("baseline_log.json", "w", encoding="utf-8") as f:
        json.dump(full_log, f, indent=4)
    print("\n>>> All trials completed! Full log saved to baseline_log.json")

if __name__ == "__main__":
    run_baseline_evaluation()