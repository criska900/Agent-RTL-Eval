import subprocess
import os
from collections import namedtuple

def verify(problem_id: str, solution) -> dict:
    """
    Simulation-Based Automatic Verifier supporting P1 to P10
    """
    verilog_code = solution.fixed_verilog_code
    tb_file = f"tb_{problem_id.lower()}.sv"
    

    base_files = ["reg_file.sv", "load_reg.sv"] 
    
    # 1. Determine what name to save the code of the large model and which files to compile based on the problem_id
    if problem_id in ["P1", "P2", "P3", "P4", "P5"]:
        dut_file = "dut_control.sv"
        with open(dut_file, "w", encoding="utf-8") as f:
            f.write(verilog_code)
        
        compile_cmd = ["iverilog", "-g2012", "-o", "sim.vvp", tb_file, dut_file, "cpu.sv", "alu.sv"] + base_files

    elif problem_id == "P6":
        dut_file = "dut_alu.sv"
        with open(dut_file, "w", encoding="utf-8") as f:
            f.write(verilog_code)
        
        compile_cmd = ["iverilog", "-g2012", "-o", "sim.vvp", tb_file, dut_file, "cpu.sv", "control.sv"] + base_files

    elif problem_id == "P7":
        dut_file = "dut_cpu.sv"
        with open(dut_file, "w", encoding="utf-8") as f:
            f.write(verilog_code)
       
        compile_cmd = ["iverilog", "-g2012", "-o", "sim.vvp", tb_file, dut_file, "control.sv", "alu.sv"] + base_files

    elif problem_id in ["P8", "P9", "P10"]:
        # Cross file bug: The code returned by the large model contains both module CPU and module ALU
        dut_file = "dut_combined.sv"
        with open(dut_file, "w", encoding="utf-8") as f:
            f.write(verilog_code)
        
        compile_cmd = ["iverilog", "-g2012", "-o", "sim.vvp", tb_file, dut_file, "control.sv"] + base_files

    else:
        return {"pass": False, "details": {}, "reason": f"Unknown problem ID: {problem_id}"}


    # 2. compile
    comp_res = subprocess.run(compile_cmd, capture_output=True, text=True)

    if comp_res.returncode != 0:
        return {
            "pass": False,
            "details": {"compilation": False},
            "reason": f"Syntax/Compilation Error:\n{comp_res.stderr.strip()}"
        }

    # 3. run stimulation
    sim_res = subprocess.run(["vvp", "sim.vvp"], capture_output=True, text=True)
    output = sim_res.stdout

    # 4. gain failure result
    reason_lines = [line.strip() for line in output.split('\n') if "FAIL:" in line]
    
    if not reason_lines:
        return {
            "pass": True,
            "details": {"compilation": True, "simulation": True},
            "reason": f"SUCCESS: All tests passed for {problem_id}."
        }
    else:
        return {
            "pass": False,
            "details": {"compilation": True, "simulation": False},
            "reason": f"Simulation Failed:\n" + "\n".join(reason_lines)
        }

# local test
if __name__ == "__main__":
    print(">>> Running the extended verifier...\n")
    MockSolution = namedtuple("MockSolution", ["fixed_verilog_code"])
    

    manual_tests = {
        "P6": {"pass_file": "alu.sv", "fail_file": "buggy_alu_p6.sv"},
        "P7": {"pass_file": "cpu.sv", "fail_file": "buggy_cpu_p7.sv"},
        "P8": {"pass_file": "combined_perfect.sv", "fail_file": "buggy_combined_p8.sv"},
        "P9": {"pass_file": "combined_perfect.sv", "fail_file": "buggy_combined_p9.sv"},
        "P10": {"pass_file": "combined_perfect.sv", "fail_file": "buggy_combined_p10.sv"}
    }
    
    # test it one by one
    test_id = "P7" 
    
    print(f"========== test {test_id} ==========")
    
    # Fail Case
    try:
        with open(manual_tests[test_id]["fail_file"], "r", encoding="utf-8") as f:
            fail_code = f.read()
        res_fail = verify(test_id, MockSolution(fixed_verilog_code=fail_code))
        print(f"[{test_id} Fail Case]:\n{res_fail}\n")
    except FileNotFoundError:
        print(f"fail to find: {manual_tests[test_id]['fail_file']}")

    # Pass Case
    try:
        with open(manual_tests[test_id]["pass_file"], "r", encoding="utf-8") as f:
            pass_code = f.read()
        res_pass = verify(test_id, MockSolution(fixed_verilog_code=pass_code))
        print(f"[{test_id} Pass Case]:\n{res_pass}\n")
    except FileNotFoundError:
        print(f"fail to find: {manual_tests[test_id]['pass_file']}")