# Environment Setup and Dependencies

## 1. Python Environment
- **Python Version**: Python 3.11

## 2. Python Packages
Install the required packages using pip:
- `openai` (version 1.14.0 or latest)
This project uses Pydant for structured output validation and interacts with OpenAI API using the Instructor library. Please use the following command to install all necessary Python packages:

```bash
pip install openai pydantic instructor

## 3. External Tools
To run the Verilog simulations, the following external tool must be installed and added to the system PATH:
- Icarus Verilog (`iverilog` & `vvp`): Used to compile and simulate the `.sv` testbenches.
